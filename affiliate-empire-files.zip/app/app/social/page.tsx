
'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import Header from '@/components/header'
import Footer from '@/components/footer'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { 
  Twitter, 
  Facebook, 
  Instagram, 
  Linkedin, 
  Calendar,
  Send,
  BarChart3,
  Settings,
  Plus,
  Clock
} from 'lucide-react'

export default function SocialMediaPage() {
  const [selectedPlatform, setSelectedPlatform] = useState('twitter')

  const platforms = [
    { id: 'twitter', name: 'Twitter', icon: Twitter, color: 'text-blue-400', connected: true },
    { id: 'facebook', name: 'Facebook', icon: Facebook, color: 'text-blue-600', connected: false },
    { id: 'instagram', name: 'Instagram', icon: Instagram, color: 'text-pink-500', connected: true },
    { id: 'linkedin', name: 'LinkedIn', icon: Linkedin, color: 'text-blue-700', connected: false },
  ]

  const scheduledPosts = [
    {
      id: 1,
      platform: 'twitter',
      content: 'Transform your health with these 5 simple daily habits that successful people swear by! 💪 #HealthTips #Wellness',
      scheduledFor: '2025-06-04T10:00:00',
      status: 'scheduled'
    },
    {
      id: 2,
      platform: 'instagram',
      content: 'The secret to building wealth isn\'t what you think... 🤔💰 Discover the mindset shift that changed everything.',
      scheduledFor: '2025-06-04T15:30:00',
      status: 'scheduled'
    },
    {
      id: 3,
      platform: 'twitter',
      content: 'Relationship tip: The 5-minute rule that can save any conversation 💕 #RelationshipGoals',
      scheduledFor: '2025-06-04T18:00:00',
      status: 'posted'
    }
  ]

  const analytics = {
    twitter: { followers: 2500, engagement: 4.2, posts: 45 },
    instagram: { followers: 1800, engagement: 6.8, posts: 32 },
    facebook: { followers: 0, engagement: 0, posts: 0 },
    linkedin: { followers: 0, engagement: 0, posts: 0 }
  }

  return (
    <div className="min-h-screen">
      <Header />
      
      {/* Hero Section */}
      <section className="py-20 hero-bg">
        <div className="container mx-auto max-w-6xl px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Social Media Automation
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Automate your social media presence across all platforms. Schedule posts, track engagement, 
              and grow your affiliate marketing reach effortlessly.
            </p>
          </motion.div>
        </div>
      </section>

      <div className="container mx-auto max-w-7xl px-4 py-12">
        {/* Platform Connections */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="mb-12"
        >
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Settings className="mr-2 h-5 w-5" />
                Platform Connections
              </CardTitle>
              <CardDescription>Connect your social media accounts to start automating</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {platforms.map((platform) => (
                  <div key={platform.id} className="flex flex-col items-center p-4 border rounded-lg">
                    <platform.icon className={`h-8 w-8 ${platform.color} mb-2`} />
                    <h3 className="font-medium mb-2">{platform.name}</h3>
                    {platform.connected ? (
                      <Badge variant="default">Connected</Badge>
                    ) : (
                      <Button size="sm" variant="outline">Connect</Button>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Post Scheduler */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="lg:col-span-2"
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Calendar className="mr-2 h-5 w-5" />
                  Schedule New Post
                </CardTitle>
                <CardDescription>Create and schedule content across all platforms</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Platform Selection */}
                <div>
                  <label className="text-sm font-medium mb-2 block">Select Platform</label>
                  <div className="flex gap-2">
                    {platforms.filter(p => p.connected).map((platform) => (
                      <Button
                        key={platform.id}
                        variant={selectedPlatform === platform.id ? "default" : "outline"}
                        size="sm"
                        onClick={() => setSelectedPlatform(platform.id)}
                        className="flex items-center"
                      >
                        <platform.icon className="h-4 w-4 mr-2" />
                        {platform.name}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Content Input */}
                <div>
                  <label className="text-sm font-medium mb-2 block">Post Content</label>
                  <textarea
                    className="w-full p-3 border rounded-md resize-none"
                    rows={4}
                    placeholder="What's on your mind? Share valuable content with your audience..."
                  />
                  <div className="text-xs text-muted-foreground mt-1">280 characters remaining</div>
                </div>

                {/* Schedule Options */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Date</label>
                    <Input type="date" />
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Time</label>
                    <Input type="time" />
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-2">
                  <Button className="flex-1">
                    <Calendar className="mr-2 h-4 w-4" />
                    Schedule Post
                  </Button>
                  <Button variant="outline">
                    <Send className="mr-2 h-4 w-4" />
                    Post Now
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Scheduled Posts */}
            <Card className="mt-8">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Clock className="mr-2 h-5 w-5" />
                    Scheduled Posts
                  </div>
                  <Button size="sm" variant="outline">
                    <Plus className="mr-2 h-4 w-4" />
                    Add Post
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {scheduledPosts.map((post) => {
                    const platform = platforms.find(p => p.id === post.platform)
                    return (
                      <div key={post.id} className="p-4 border rounded-lg">
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex items-center">
                            {platform && <platform.icon className={`h-4 w-4 ${platform.color} mr-2`} />}
                            <span className="text-sm font-medium">{platform?.name}</span>
                          </div>
                          <Badge variant={post.status === 'posted' ? 'default' : 'secondary'}>
                            {post.status}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">{post.content}</p>
                        <div className="text-xs text-muted-foreground">
                          {new Date(post.scheduledFor).toLocaleString()}
                        </div>
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Analytics Sidebar */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="space-y-6"
          >
            {/* Quick Stats */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BarChart3 className="mr-2 h-5 w-5" />
                  Quick Stats
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {platforms.filter(p => p.connected).map((platform) => {
                    const stats = analytics[platform.id as keyof typeof analytics]
                    return (
                      <div key={platform.id} className="p-3 bg-muted/50 rounded-lg">
                        <div className="flex items-center mb-2">
                          <platform.icon className={`h-4 w-4 ${platform.color} mr-2`} />
                          <span className="font-medium">{platform.name}</span>
                        </div>
                        <div className="grid grid-cols-3 gap-2 text-sm">
                          <div>
                            <div className="font-medium">{stats.followers}</div>
                            <div className="text-xs text-muted-foreground">Followers</div>
                          </div>
                          <div>
                            <div className="font-medium">{stats.engagement}%</div>
                            <div className="text-xs text-muted-foreground">Engagement</div>
                          </div>
                          <div>
                            <div className="font-medium">{stats.posts}</div>
                            <div className="text-xs text-muted-foreground">Posts</div>
                          </div>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Content Ideas */}
            <Card>
              <CardHeader>
                <CardTitle>Content Ideas</CardTitle>
                <CardDescription>AI-generated post suggestions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[
                    "5 morning habits that successful entrepreneurs swear by",
                    "The psychology behind impulse buying and how to overcome it",
                    "Why 90% of relationships fail and how to be in the 10%",
                    "The compound effect: Small changes, massive results"
                  ].map((idea, index) => (
                    <div key={index} className="p-3 bg-muted/50 rounded-lg text-sm">
                      {idea}
                      <Button size="sm" variant="ghost" className="ml-2 h-6 px-2">
                        Use
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>

      <Footer />
    </div>
  )
}
