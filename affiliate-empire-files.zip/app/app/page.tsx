export default function HomePage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-16">
        <h1 className="text-4xl font-bold text-center mb-8">
          Affiliate Empire - Automated Marketing System
        </h1>
        <p className="text-xl text-center text-gray-600 mb-12">
          Fully automated affiliate marketing system generating passive income 24/7
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-lg font-semibold mb-4">AI Content Generation</h3>
            <p className="text-gray-600">Automated blog posts with SEO optimization</p>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-lg font-semibold mb-4">Email Automation</h3>
            <p className="text-gray-600">Automated email sequences and newsletters</p>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-lg font-semibold mb-4">Social Media</h3>
            <p className="text-gray-600">Multi-platform posting automation</p>
          </div>
        </div>
      </div>
    </div>
  );
}