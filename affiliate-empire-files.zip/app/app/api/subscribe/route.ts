
import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function POST(request: NextRequest) {
  try {
    const { email, firstName, lastName, source } = await request.json()

    if (!email) {
      return NextResponse.json(
        { error: 'Email is required' },
        { status: 400 }
      )
    }

    // Check if subscriber already exists
    const existingSubscriber = await prisma.emailSubscriber.findUnique({
      where: { email }
    })

    if (existingSubscriber) {
      // Update existing subscriber
      const updatedSubscriber = await prisma.emailSubscriber.update({
        where: { email },
        data: {
          firstName: firstName || existingSubscriber.firstName,
          lastName: lastName || existingSubscriber.lastName,
          source: source || existingSubscriber.source,
          active: true,
          updatedAt: new Date()
        }
      })

      return NextResponse.json({
        message: 'Subscription updated successfully',
        subscriber: updatedSubscriber
      })
    }

    // Create new subscriber
    const newSubscriber = await prisma.emailSubscriber.create({
      data: {
        email,
        firstName: firstName || null,
        lastName: lastName || null,
        source: source || 'unknown',
        tags: [],
        active: true,
        confirmed: false
      }
    })

    return NextResponse.json({
      message: 'Subscribed successfully',
      subscriber: newSubscriber
    }, { status: 201 })

  } catch (error) {
    console.error('Subscription error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function GET() {
  try {
    const subscribers = await prisma.emailSubscriber.findMany({
      where: { active: true },
      orderBy: { createdAt: 'desc' },
      take: 100
    })

    return NextResponse.json({ subscribers })
  } catch (error) {
    console.error('Error fetching subscribers:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
