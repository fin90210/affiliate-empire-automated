
'use client'

import { useEffect } from 'react'
import { useParams } from 'next/navigation'

export default function RedirectPage() {
  const params = useParams()

  useEffect(() => {
    const trackAndRedirect = async () => {
      try {
        const response = await fetch(`/api/affiliate-links/${params.id}/click`, {
          method: 'POST'
        })
        
        if (response.ok) {
          const data = await response.json()
          window.location.href = data.redirectUrl
        } else {
          // Fallback redirect to homepage if link not found
          window.location.href = '/'
        }
      } catch (error) {
        console.error('Error tracking click:', error)
        window.location.href = '/'
      }
    }

    if (params.id) {
      trackAndRedirect()
    }
  }, [params.id])

  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
        <p className="text-muted-foreground">Redirecting...</p>
      </div>
    </div>
  )
}
