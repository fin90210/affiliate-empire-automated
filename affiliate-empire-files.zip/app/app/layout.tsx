
import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'Affiliate Empire - Automated Affiliate Marketing System',
  description: 'Fully automated affiliate marketing system with AI content generation, email automation, and social media management. Generate passive income 24/7.',
  keywords: 'affiliate marketing, automation, AI content, email marketing, passive income',
  authors: [{ name: 'Affiliate Empire' }],
  openGraph: {
    title: 'Affiliate Empire - Automated Affiliate Marketing System',
    description: 'Generate passive income with our fully automated affiliate marketing system',
    type: 'website',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        {children}
      </body>
    </html>
  );
}
