
'use client'

import { motion } from 'framer-motion'
import Image from 'next/image'
import Link from 'next/link'
import Header from '@/components/header'
import Footer from '@/components/footer'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Heart, DollarSign, Users, ArrowRight, Star, CheckCircle } from 'lucide-react'

export default function CategoriesPage() {
  const categories = [
    {
      title: 'Health & Wellness',
      description: 'Transform your physical and mental well-being with proven strategies',
      icon: Heart,
      color: 'text-red-500',
      bgColor: 'bg-red-50',
      image: 'https://i.pinimg.com/originals/e5/13/9f/e5139fe249283c6acf3594a5e44788f5.jpg',
      features: [
        'Weight Loss Programs',
        'Fitness Equipment',
        'Nutrition Supplements',
        'Mental Health Resources',
        'Sleep Optimization',
        'Stress Management'
      ],
      stats: {
        products: '50+',
        avgCommission: '25%',
        topEarning: '$500/month'
      }
    },
    {
      title: 'Wealth Building',
      description: 'Create multiple income streams and build lasting financial freedom',
      icon: DollarSign,
      color: 'text-green-500',
      bgColor: 'bg-green-50',
      image: 'https://img.freepik.com/premium-photo/growth-money-arrow-success-financial-business-coin-concept-investment-earnings-background-with-profit-graph-finance-development-increase-economic-market-chart-digital-stock-currency-strategy_79161-2472.jpg',
      features: [
        'Investment Courses',
        'Trading Platforms',
        'Business Tools',
        'Real Estate Programs',
        'Cryptocurrency Guides',
        'Financial Planning'
      ],
      stats: {
        products: '75+',
        avgCommission: '40%',
        topEarning: '$1,200/month'
      }
    },
    {
      title: 'Relationships',
      description: 'Build meaningful connections and improve your personal relationships',
      icon: Users,
      color: 'text-blue-500',
      bgColor: 'bg-blue-50',
      image: 'https://i.pinimg.com/originals/53/d9/5c/53d95c7802d8a35e70638c45868aac02.jpg',
      features: [
        'Dating Courses',
        'Communication Skills',
        'Marriage Counseling',
        'Social Confidence',
        'Family Harmony',
        'Personal Development'
      ],
      stats: {
        products: '30+',
        avgCommission: '35%',
        topEarning: '$800/month'
      }
    }
  ]

  return (
    <div className="min-h-screen">
      <Header />
      
      {/* Hero Section */}
      <section className="py-20 hero-bg">
        <div className="container mx-auto max-w-6xl px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Explore Our Categories
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Discover high-converting affiliate programs across the most profitable niches. 
              Start earning with products that truly transform lives.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-20">
        <div className="container mx-auto max-w-6xl px-4">
          <div className="space-y-16">
            {categories.map((category, index) => (
              <motion.div
                key={category.title}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.2 }}
                className={`${index % 2 === 1 ? 'lg:flex-row-reverse' : ''}`}
              >
                <Card className="overflow-hidden">
                  <div className={`grid lg:grid-cols-2 gap-0 ${index % 2 === 1 ? 'lg:grid-cols-2' : ''}`}>
                    {/* Image */}
                    <div className="relative aspect-video lg:aspect-auto bg-muted">
                      <Image
                        src={category.image}
                        alt={category.title}
                        fill
                        className="object-cover"
                      />
                    </div>
                    
                    {/* Content */}
                    <div className="p-8 lg:p-12">
                      <div className={`p-3 rounded-full w-fit ${category.bgColor} mb-6`}>
                        <category.icon className={`h-8 w-8 ${category.color}`} />
                      </div>
                      
                      <h2 className="text-3xl font-bold mb-4">{category.title}</h2>
                      <p className="text-lg text-muted-foreground mb-6">{category.description}</p>
                      
                      {/* Stats */}
                      <div className="grid grid-cols-3 gap-4 mb-8">
                        <div className="text-center">
                          <div className="text-2xl font-bold text-primary">{category.stats.products}</div>
                          <div className="text-sm text-muted-foreground">Products</div>
                        </div>
                        <div className="text-center">
                          <div className="text-2xl font-bold text-primary">{category.stats.avgCommission}</div>
                          <div className="text-sm text-muted-foreground">Avg Commission</div>
                        </div>
                        <div className="text-center">
                          <div className="text-2xl font-bold text-primary">{category.stats.topEarning}</div>
                          <div className="text-sm text-muted-foreground">Top Earning</div>
                        </div>
                      </div>
                      
                      {/* Features */}
                      <div className="grid grid-cols-2 gap-3 mb-8">
                        {category.features.map((feature) => (
                          <div key={feature} className="flex items-center text-sm">
                            <CheckCircle className="h-4 w-4 text-green-500 mr-2 flex-shrink-0" />
                            {feature}
                          </div>
                        ))}
                      </div>
                      
                      <div className="flex gap-4">
                        <Button size="lg">
                          Explore Products
                          <ArrowRight className="ml-2 h-5 w-5" />
                        </Button>
                        <Button variant="outline" size="lg">
                          View Stats
                          <Star className="ml-2 h-5 w-5" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto max-w-6xl px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Ready to Start Earning?
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
              Join thousands of successful affiliates who are already earning with our proven system. 
              Get access to exclusive products and higher commission rates.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="text-lg px-8">
                Get Started Today
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button variant="outline" size="lg" className="text-lg px-8">
                Learn More
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
